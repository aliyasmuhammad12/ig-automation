// scripts/humanSwipe.js
// A feature-complete swipe engine that integrates all helper layers
// (grip, curviness, tremor, lateral, outliers, timing, session, profiles, params, path, touch).
// Designed to be edited step-by-step. All hooks are present; missing helpers are optional via fallbacks.

// ------------------------------ Imports (defensive) ------------------------------

function tryRequire(path) {
  try { return require(path); } catch (_) { return {}; }
}

// params.js exports the object itself (NOT { DEFAULTS })
const DEFAULTS = (() => {
  try { return require('../humanSwipe-Helpers/params'); }
  catch (_) { return {}; }
})();

// core helpers
const utils = tryRequire('../humanSwipe-Helpers/utils');
const timing = tryRequire('../humanSwipe-Helpers/timing');
const tremor = tryRequire('../humanSwipe-Helpers/tremor');
const lateral = tryRequire('../humanSwipe-Helpers/lateral');
const outliers = tryRequire('../humanSwipe-Helpers/outliers');
const curviness = tryRequire('../humanSwipe-Helpers/curviness');
const grip = tryRequire('../humanSwipe-Helpers/grip');
const sessionMod = tryRequire('../humanSwipe-Helpers/session');
const profiles = tryRequire('../humanSwipe-Helpers/profiles');
const pathMod = tryRequire('../humanSwipe-Helpers/path');
const touch = tryRequire('../humanSwipe-Helpers/touch');

// selectors (not strictly needed here but available for future taps/likes before/after swipe)
const selectors = (() => {
  try { return require('../selectors'); }
  catch (_) { return {}; }
})();

// ------------------------------ Safe accessors / fallbacks ------------------------------

const clamp = utils.clamp || ((v, lo, hi) => Math.max(lo, Math.min(hi, v)));
const jitter = utils.jitter || ((v, j) => v + (Math.random() * 2 - 1) * (j || 0));
const randInt = utils.randInt || ((a, b) => Math.floor(Math.random() * (b - a + 1)) + a);
const randFloat = utils.randFloat || ((a, b) => Math.random() * (b - a) + a);
const pick = utils.pick || ((arr) => arr[Math.floor(Math.random() * arr.length)]);
const pickWeighted = utils.pickWeighted || ((items) => {
  // items: [{value, weight}]
  const sum = items.reduce((s, it) => s + (it.weight || 1), 0);
  let r = Math.random() * sum;
  for (const it of items) {
    r -= (it.weight || 1);
    if (r <= 0) return it.value;
  }
  return items.at(-1)?.value;
});

const buildSwipePath = pathMod.buildSwipePath || ((cfg = {}) => {
  // Fallback starter if path module missing: simple linear path
  const stepsN = cfg.stepsN || 16;
  const dx = cfg.dx || 0;
  const dy = cfg.dy || -500;
  const dur = cfg.swipeDurationMs || 420;
  const delays = (timing.buildDelaysForDuration && timing.buildDelaysForDuration(dur, stepsN))
    || Array.from({ length: stepsN }, () => dur / stepsN);
  const out = [];
  for (let i = 1; i <= stepsN; i++) {
    out.push({
      x: Math.round((dx * i) / stepsN),
      y: Math.round((dy * i) / stepsN),
      delayMs: delays[i - 1],
    });
  }
  return out;
});

const {
  getClient = async (page) => await page.target().createCDPSession(),
  touchStart = async () => {},
  touchMove = async () => {},
  touchEnd = async () => {},
  sleepMs = (ms) => new Promise((r) => setTimeout(r, ms)),
} = touch;

const {
  scheduleNextGripShift = () => {},
  maybeStartLeftMode = () => {},
  endLeftModeIfNeeded = () => {},
  applyGripShiftIntra = (pt) => pt,
} = grip;

const {
  expireCurvinessIfDone = () => {},
  maybeStartCurvinessBurstOnShift = () => {},
  currentCurviness = () => null,
} = curviness;

const {
  genTremorSequence = () => [],
} = tremor;

const {
  applyLateralVariants = (steps) => steps,
} = lateral;

const {
  maybeLongPause = async () => {},
  maybeLateralSpike = (steps) => steps,
  maybeCurvySurge = (cfg) => cfg,
} = outliers;

const {
  initPersonaOnce = (s) => s || { createdAt: Date.now(), swipeCount: 0 },
  maybeDriftMeta = (s) => s,
  bumpSwipeCount = (s) => { if (s) s.swipeCount = (s.swipeCount || 0) + 1; return s; },
} = sessionMod;

const {
  applyProfileOverrides = (cfg, meta) => ({ cfg, meta }),
} = profiles;

// ------------------------------ Defaults (safe) ------------------------------

const FALLBACKS = {
  dyRangePx: [-620, -420],         // swipe up to next reel (adaptive floor below)
  dxRangePx: [-6, 6],              // slight sideways drift allowed
  stepsRange: [14, 24],            // number of path steps
  durationRangeMs: [360, 620],     // total swipe duration
  startXJitterRatio: 0.06,         // vs viewport width
  startYRatio: 0.72,               // start lower on screen (thumb reach)
  startYJitterRatio: 0.04,
  tremorPxRange: [0.2, 1.2],       // micro-jitter amplitude
};

function getParam(pathArr, fallback) {
  let ref = DEFAULTS;
  for (const k of pathArr) {
    if (!ref || typeof ref !== 'object') return fallback;
    ref = ref[k];
  }
  return (ref === undefined ? fallback : ref);
}

// ------------------------------ Core helpers ------------------------------

async function chooseStartPoint(page, cfg = {}) {
  const vp = page?.viewport?.() || {};
  const w = vp.width || 390;
  const h = vp.height || 844;

  if (typeof cfg.startX === 'number' && typeof cfg.startY === 'number') {
    return { x: cfg.startX, y: cfg.startY, w, h };
  }

  const xJ = cfg.startXJitterRatio ?? getParam(['startXJitterRatio'], FALLBACKS.startXJitterRatio);
  const yBaseR = cfg.startYRatio ?? getParam(['startYRatio'], FALLBACKS.startYRatio);
  const yJ = cfg.startYJitterRatio ?? getParam(['startYJitterRatio'], FALLBACKS.startYJitterRatio);

  const x = Math.round(w / 2 + randFloat(-w * xJ, w * xJ));
  const y = Math.round(h * yBaseR + randFloat(-h * yJ, h * yJ));

  return { x, y, w, h };
}

function decideMotion(meta, cfg = {}, page) {
  const vp = page?.viewport?.() || {};
  const h = vp.height || 844;

  const dxR = cfg.dxRangePx ?? getParam(['swipeDxPxRange'], FALLBACKS.dxRangePx);
  const dyR = cfg.dyRangePx ?? getParam(['swipeDyPxRange'], FALLBACKS.dyRangePx);
  const stepsR = cfg.stepsRange ?? getParam(['stepsRange'], FALLBACKS.stepsRange);
  const durR = cfg.durationRangeMs ?? getParam(['swipeDurationRangeMs'], FALLBACKS.durationRangeMs);

  const dx = clamp(randInt(dxR[0], dxR[1]), -50, 50);

  // Candidate dy from config; if too short, auto-upgrade to ~80–88% of viewport height
  let dyCand = clamp(randInt(dyR[0], dyR[1]), -1500, 1500);
  const minMag = Math.round(h * 0.70);
  let dy = (Math.abs(dyCand) < minMag)
    ? -Math.round(h * (0.80 + Math.random() * 0.08))
    : dyCand;

  const stepsN = clamp(randInt(stepsR[0], stepsR[1]), 6, 48);
  const swipeDurationMs = clamp(randInt(durR[0], durR[1]), 180, 1400);

  return { dx, dy, stepsN, swipeDurationMs };
}

function applyCurvinessAndLateral(cfg, meta, steps) {
  // Allow curviness bursts to affect cfg
  maybeStartCurvinessBurstOnShift(meta);
  expireCurvinessIfDone(meta);

  const curvy = currentCurviness(meta);
  if (curvy) {
    cfg.curviness = (typeof cfg.curviness === 'number')
      ? (cfg.curviness + curvy) / 2
      : curvy;
  }

  // Outlier lateral spike can inject shape
  steps = maybeLateralSpike(steps);

  // Lateral variants (arc/slant/breaks)
  steps = applyLateralVariants(steps);

  return { cfg, steps };
}

function applyTremorToSteps(steps, meta, cfg = {}) {
  const range = cfg.tremorPxRange
    ?? getParam(['tremorPxRange'], FALLBACKS.tremorPxRange);

  if (!range || !Array.isArray(range)) return steps;

  const tremSeq = genTremorSequence(steps.length, range);
  if (!tremSeq || tremSeq.length !== steps.length) return steps;

  const out = [];
  for (let i = 0; i < steps.length; i++) {
    const s = steps[i];
    const t = tremSeq[i] || { x: 0, y: 0 };
    out.push({ x: s.x + t.x, y: s.y + t.y, delayMs: s.delayMs });
  }
  return out;
}

function applyGripShift(point, meta) {
  // Shift hand “grip” intra-swipe
  return applyGripShiftIntra(point, meta) || point;
}

function withProfileOverrides(cfg, meta) {
  const res = applyProfileOverrides(cfg, meta);
  if (!res) return { cfg, meta };
  // Support either returning cfg directly or an object {cfg, meta}
  if (res.cfg || res.meta) return { cfg: res.cfg || cfg, meta: res.meta || meta };
  return { cfg: res, meta };
}

// ------------------------------ Event driver ------------------------------

async function dispatchSwipeFrom(page, start, steps, opts = {}) {
  // Send CDP touch events from absolute positions start + relative step
  const client = await getClient(page);
  const startAbs = { x: start.x, y: start.y };

  // touchStart at the start anchor
  await touchStart(client, startAbs.x, startAbs.y);

  let curr = { ...startAbs };
  for (const step of steps) {
    const pt = { x: Math.round(startAbs.x + step.x), y: Math.round(startAbs.y + step.y) };
    const shifted = applyGripShift(pt, opts.meta);

    await sleepMs(step.delayMs || 0);
    await touchMove(client, shifted.x, shifted.y);

    curr = shifted;
  }

  await touchEnd(client);
}

// ------------------------------ Public API ------------------------------

/**
 * swipeNext(page, cfg)
 * - Builds a human-like vertical swipe path and dispatches it via CDP touch events.
 * - Integrates: session persona, grip, curviness, tremor, lateral, outliers, profiles, timing.
 *
 * @param {import('puppeteer').Page|any} page
 * @param {Object} cfg Optional overrides:
 *   - dxRangePx, dyRangePx, stepsRange, durationRangeMs
 *   - startX, startY, startXJitterRatio, startYRatio, startYJitterRatio
 *   - curviness, tremorPxRange
 *   - any profile/session hooks you plan to inject
 */
async function swipeNext(page, cfg = {}) {
  // ----- Session / persona
  let session = initPersonaOnce(cfg.session);
  session = maybeDriftMeta(session);

  // Optional: hand mode transitions before a new swipe
  maybeStartLeftMode(session);
  endLeftModeIfNeeded(session);
  scheduleNextGripShift(session);

  // ----- Start point
  const start = await chooseStartPoint(page, cfg);

  // ----- Motion decisions
  let motion = decideMotion(session, cfg, page);
  motion = maybeCurvySurge(motion); // outlier surge may tweak dy/duration

  // ----- Timing / delays
  const stepsN = motion.stepsN;
  const totalMs = motion.swipeDurationMs;

  const delays =
    (timing.buildDelaysForDuration && timing.buildDelaysForDuration(totalMs, stepsN))
    || Array.from({ length: stepsN }, () => totalMs / stepsN);

  // ----- Build path (relative steps)
  // Allow profiles to override cfg before path creation
  let cfgMerged = { ...cfg, ...motion };
  ({ cfg: cfgMerged } = withProfileOverrides(cfgMerged, session));

  let steps = buildSwipePath(cfgMerged, { session, profile: cfg.profile });

  // If path module didn't generate delays, inject ours
  if (!steps?.length) {
    steps = [];
    for (let i = 1; i <= stepsN; i++) {
      steps.push({
        x: Math.round((motion.dx * i) / stepsN),
        y: Math.round((motion.dy * i) / stepsN),
        delayMs: delays[i - 1],
      });
    }
  } else {
    // normalize delayMs length
    if (!('delayMs' in steps[0])) {
      steps = steps.map((s, i) => ({ ...s, delayMs: delays[i] || 0 }));
    }
  }

  // ----- Shape modifiers (lateral, curviness, tremor)
  ({ cfg: cfgMerged, steps } = applyCurvinessAndLateral(cfgMerged, session, steps));
  steps = applyTremorToSteps(steps, session, cfgMerged);

  // ----- Rare outlier pause before or after
  await maybeLongPause(session);

  // ----- Dispatch!
  await dispatchSwipeFrom(page, start, steps, { meta: session });

  // ----- Session bookkeeping
  bumpSwipeCount(session);

  // Return final meta for chaining
  return { session, start, motion: cfgMerged, stepsCount: steps.length };
}

// Convenience variant: swipe up a specific pixel amount (dy negative)
async function swipeUp(page, dyPx = -500, cfg = {}) {
  return swipeNext(page, { ...cfg, dyRangePx: [dyPx, dyPx] });
}

// Convenience variant: swipe down a specific pixel amount (dy positive)
async function swipeDown(page, dyPx = 500, cfg = {}) {
  return swipeNext(page, { ...cfg, dyRangePx: [dyPx, dyPx] });
}

module.exports = {
  swipeNext,
  swipeUp,
  swipeDown,
};
