// humanize/scripts/watchReels.js
// Reels micro-session using the humanSwipe engine (tremor, lateral, curviness, outliers, fatigue).

const { swipeNext } = require('./humanSwipe');

const now = () => Date.now();
const sleep = (ms) => new Promise((res) => setTimeout(res, ms));
const rFloat = (a, b) => a + Math.random() * (b - a);
const rInt = (a, b) => Math.floor(rFloat(a, b + 1));

async function enableTouchEmulation(page) {
  const cdp = await page.target().createCDPSession();
  await cdp.send('Emulation.setTouchEmulationEnabled', { enabled: true });
}

async function killCommonBlockers(page) {
  const sels = [
    'div[role="dialog"] button[aria-label="Close"]',
    'div[role="dialog"] [role="button"][tabindex]:not([disabled])',
    'div[role="dialog"] button[type="button"]',
    'div[role="dialog"] [role="button"]:not([disabled])',
  ];
  for (const sel of sels) {
    try {
      const el = await page.$(sel);
      if (el) { await el.click({ delay: rInt(15, 45) }); await sleep(rInt(120, 240)); }
    } catch {}
  }
}

async function ensureReelFocused(page) {
  await page.evaluate(() => {
    const v = document.querySelector('main video[src], div[role="dialog"] video[src]');
    if (v) v.focus?.();
  });
}

async function getSafeStartPoint(page) {
  return page.evaluate(() => {
    const bad = el =>
      !el ||
      el.closest('[role="dialog"]') ||
      /^(SPAN|NAV|FOOTER)$/i.test(el.tagName);

    let x = Math.round(innerWidth * 0.52);
    let y = Math.round(innerHeight * 0.74);
    const v = document.querySelector('main video[src], div[role="dialog"] video[src]');
    if (v) {
      const r = v.getBoundingClientRect();
      x = Math.round(r.left + r.width * 0.52);
      y = Math.round(r.top  + r.height * 0.74);
    }
    for (let i = 0; i < 5; i++) {
      const hit = document.elementFromPoint(x, y);
      if (!bad(hit)) break;
      y -= 60;
    }
    return { x, y, vh: innerHeight };
  });
}

async function likeIfPossible(page) {
  const selectors = [
    'svg[aria-label="Like"]',
    'button[aria-label="Like"]',
    'svg[height][width][role="img"][aria-label="Like"]',
  ];
  for (const sel of selectors) {
    const el = await page.$(sel);
    if (!el) continue;
    try { await el.click({ delay: rInt(10, 60) }); return true; } catch {}
  }
  return false;
}

async function maybeGlanceComments(page) {
  const openSel  = 'svg[aria-label="Comment"], button[aria-label="Comment"]';
  const closeSel = 'div[role="dialog"] button[aria-label="Close"], svg[aria-label="Close"]';
  try {
    const btn = await page.$(openSel);
    if (!btn) return false;
    await btn.click({ delay: rInt(15, 50) });
    await sleep(rInt(350, 900));
    const close = await page.$(closeSel);
    if (close) { await close.click({ delay: rInt(15, 50) }); }
    return true;
  } catch { return false; }
}

async function maybePeekProfile(page) {
  const sel = 'header a[role="link"][href*="/"], a[role="link"] img[alt*=" profile picture"]';
  try {
    const el = await page.$(sel);
    if (!el) return false;
    await el.click({ delay: rInt(15, 45) });
    await sleep(rInt(400, 900));
    await page.keyboard.press('Escape').catch(() => {});
    return true;
  } catch { return false; }
}

module.exports = {
  name: 'watchReels',
  weight: 1,
  cooldownMs: 15000,
  dailyCap: 120,

  async run(page, runSeconds = 60, opts = {}) {
    const cfg = {
      dwellBuckets: [
        { range: [2, 4],  w: 1 },
        { range: [4, 7],  w: 3 },
        { range: [7, 11], w: 3 },
        { range: [11, 16], w: 2 },
        { range: [16, 24], w: 1 },
      ],
      rewatchChance: 0.06,
      likeChanceBase: 0.16,
      likeDecay: 0.92,
      commentsGlanceChance: 0.07,
      profilePeekChance: 0.05,
      tapNoiseOnce: false,
      betweenReelPauseMs: [350, 1200],
      swipeDy: null,
      maxLikes: 3,
      maxPeeks: 2,
      maxCommentsGlance: 2,
      ...opts,
    };

    const state = {
      reelsSeen: 0,
      likes: 0,
      peeks: 0,
      glances: 0,
      likeP: cfg.likeChanceBase,
      _swipeSession: {},
    };

    await sleep(rInt(500, 1400));
    await enableTouchEmulation(page);
    await killCommonBlockers(page).catch(() => {});
    await ensureReelFocused(page);

    const start = now();
    while ((now() - start) / 1000 < runSeconds) {
      const safe = await getSafeStartPoint(page).catch(() => null);
      const vp = page.viewport() || { width: 360, height: 640 };
      const h = vp.height || 640;
      const dyUp = -Math.round(h * rFloat(0.82, 0.90));

      try {
        await swipeNext(page, {
          ...(safe ? { startX: safe.x, startY: safe.y } : {}),
          dyRangePx: [dyUp, dyUp],
          stepsRange: [12, 18],
          durationRangeMs: [240, 420],
          tremorPxRange: [0.2, 0.8],
          session: state._swipeSession,
        });
      } catch {
        await sleep(rInt(200, 600));
      }

      state.reelsSeen++;

      if (state.likes < cfg.maxLikes && Math.random() < state.likeP) {
        if (await likeIfPossible(page)) state.likes++;
        state.likeP *= cfg.likeDecay;
      }
      if (state.glances < cfg.maxCommentsGlance && Math.random() < cfg.commentsGlanceChance) {
        if (await maybeGlanceComments(page)) state.glances++;
      }
      if (state.peeks < cfg.maxPeeks && Math.random() < cfg.profilePeekChance) {
        if (await maybePeekProfile(page)) state.peeks++;
      }

      await sleep(rInt(cfg.betweenReelPauseMs[0], cfg.betweenReelPauseMs[1]));
      if ((now() - start) / 1000 >= runSeconds) break;

      const bucket = (() => {
        const total = cfg.dwellBuckets.reduce((s, b) => s + b.w, 0);
        let roll = Math.random() * total;
        for (const b of cfg.dwellBuckets) {
          if ((roll -= b.w) <= 0) return b.range;
        }
        return cfg.dwellBuckets[cfg.dwellBuckets.length - 1].range;
      })();
      const dwell = rInt(bucket[0], bucket[1]);
      await sleep(rInt(dwell * 250, dwell * 350));
    }

    return {
      ok: true,
      reelsSeen: state.reelsSeen,
      likes: state.likes,
      peeks: state.peeks,
      glances: state.glances,
      durationSec: Math.round((now() - start) / 1000),
    };
  },
};
