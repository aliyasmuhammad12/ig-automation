// humanize/run.js
// Minimal test runner: use EXACT AdsPower profile from CLI args and run watchReels

const { ADSPOWER_API_PORT } = require('../config');
const { launchAdsPowerBrowser } = require('../helpers/adsPower');
const task = require('./scripts/watchReels');

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

(async () => {
  const profileId = process.argv[2];
  const runSeconds = Number(process.argv[3] || 60);

  if (!profileId) {
    console.error('Usage: node humanize/run.js <PROFILE_ID> [SECONDS]');
    process.exit(1);
  }

  console.log(`🟢 Using EXACT AdsPower profile: ${profileId} (port ${ADSPOWER_API_PORT})`);

  const { browser, page } = await launchAdsPowerBrowser(profileId, ADSPOWER_API_PORT);

  try {
    await page.setViewport({ width: 390, height: 844, isMobile: true, deviceScaleFactor: 2 });

    console.log('🌐 Navigating to Instagram Reels…');
    await page.goto('https://www.instagram.com/reels/', { waitUntil: 'networkidle2', timeout: 120000 });

    await sleep(1500 + Math.floor(Math.random() * 1500));

    console.log(`🎬 Running watchReels for ~${runSeconds}s…`);
    const result = await task.run(page, runSeconds);

    console.log('✅ watchReels finished:', result);
  } catch (err) {
    console.error('❌ Runner error:', err?.message || err);
    process.exitCode = 1;
  } finally {
    await sleep(500);
    await browser.close();
  }
})();
